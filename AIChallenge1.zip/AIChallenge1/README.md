# SETTING UP THE CHALLENGE--
'''
RUN docker compose up --build
'''

After build, the container needs to be run in interactive mode to get a command prompt.

'''
docker run -it -v ollama:/root/.ollama -p 11434:11434 --name systemchallenge aichallenge12-app

~~docker run -d -p 3000:8080 -v ollama:/root/.ollama -v open-webui:/app/backend/data --name systemchallenge aichallenge1-app~~
'''