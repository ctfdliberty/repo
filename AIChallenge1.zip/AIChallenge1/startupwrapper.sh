#!/bin/bash

# Start the first process
/bin/ollama serve &
#/bin/open-webui serve
SERVE_PID=$!
a=0
#while [ $a -lt 2 ]
#do
#    echo `ps`
#    sleep 1
#done
# Start the second process
#./my_second_process &

echo Waiting for startup...
while [ "$(ollama list | grep 'NAME')" == "" ]; do
  sleep 1
done
echo Loading. Setting up model.
/bin/ollama pull tinydolphin
/bin/ollama create challenge -f /usr/bin/Modelfile.txt
echo
echo
echo
echo Challenge ready. Starting...
echo
echo
echo
/bin/ollama run challenge
# Wait for any process to exit
echo Thanks for communicating. Run the box to 
#wait $SERVE_PID

# Exit with status of process that exited first
#exit $?