docker run -d -v ollama:/root/.ollama -p 11434:11434 --name challengeAI1 aichallenge1-app
docker exec challengeAI1 ollama pull tinydolphin
docker exec challengeAI1 ollama create challenge2 -f /usr/bin/Modelfile2.txt
docker exec -it challengeAI1 ollama run challenge2