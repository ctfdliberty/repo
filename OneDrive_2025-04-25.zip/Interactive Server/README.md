### Connecting with OLLAMA

When you're ready, start your application by running:
`docker compose up --build`.

This docker container is a simple apache server that will enable the user to talk to whatever ollama model is operating. The user navigates to a port (currently set to :3000) and opens the index.html file (x.x.x.x:3000/index.html) so long as an OLLAMA server is running on the standard port (:11434) the page will directly communicate with it.